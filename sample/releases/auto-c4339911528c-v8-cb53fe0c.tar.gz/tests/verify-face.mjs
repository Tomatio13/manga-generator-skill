import assert from 'node:assert/strict';
import {
  validateFaceDesign,
  referenceInstructions,
  faceReviewTemplate,
  validateFaceReview,
} from '../src/face-design.mjs';
const reference = 'works/test/assets/face.png';
const config = {
  version: 8,
  references: [reference],
  referenceRoles: { [reference]: 'Face geometry and pen rendering only' },
  cast: {
    a: {
      faceDesign: {
        traits: [
          'Horizontal eyelids',
          'Short strong brows',
          'Round short chin',
        ],
        reference,
        settingBasis: 'Adaptation design',
      },
    },
    n: { kind: 'caption' },
  },
};
const local = (f) => {
  assert.ok(!f.includes('..'));
  return f;
};
validateFaceDesign(config, local);
const panel = {
  speakers: { a: { face: [1, 2, 3, 4] }, n: { kind: 'offscreen' } },
};
const empty = faceReviewTemplate(config, panel);
assert.throws(() => validateFaceReview(config, panel, empty));
const good = {
  faceIdentity: {
    a: {
      reference,
      traits: [
        'Lids remain horizontal',
        'Brows remain short',
        'Chin remains rounded',
      ],
      expression: 'Looking sideways with a worried mouth',
    },
  },
};
validateFaceReview(config, panel, good);
assert.throws(() => validateFaceReview(config, panel, { faceIdentity: {} }));
assert.throws(() =>
  validateFaceReview(config, panel, {
    faceIdentity: { a: { ...good.faceIdentity.a, reference: 'other.png' } },
  }),
);
assert.throws(() =>
  validateFaceDesign(
    {
      ...config,
      cast: {
        a: {
          faceDesign: { ...config.cast.a.faceDesign, traits: ['One trait'] },
        },
      },
    },
    local,
  ),
);
assert.throws(() => validateFaceDesign({ ...config, references: [] }, local));
assert.notEqual(
  referenceInstructions(config, [reference]),
  referenceInstructions(
    { ...config, referenceRoles: { [reference]: 'Costume only' } },
    [reference],
  ),
);
assert.deepEqual(
  faceReviewTemplate(config, { speakers: { a: { kind: 'head' } } }),
  { faceIdentity: {} },
);
assert.equal(referenceInstructions({ ...config, version: 7 }, [reference]), '');
console.log(
  'PASS: face traits, reference roles, visible actors, missing and mismatched face reviews',
);
